package org.example.paymentservice.controller;

import org.example.paymentservice.model.Payment;
import org.example.paymentservice.model.Request;
import org.example.paymentservice.service.AllPaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ConcurrentModel;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import reactor.core.publisher.Mono;

@Controller
public class AppController {
    private static Logger log = LoggerFactory.getLogger(AppController.class);
    @Value("${stripe.api.publicKey}")
    private String publicKey;
    private final AllPaymentService paymentService ;

    public AppController(AllPaymentService paymentService) {
        this.paymentService = paymentService;
    }

//    @GetMapping("/")
//    public Mono<String> home(Model model) {
//        model.addAttribute("request", new Request());
//        return Mono.just("index");
//    }
@GetMapping("/")
public Mono<String> home(@RequestParam(value = "paymentId", required = false, defaultValue = "") String paymentId,
                         @RequestParam(value = "bookingId", required = false, defaultValue = "") String bookingId,
                         @RequestParam(value = "amount", required = false, defaultValue = "0") String amount,
                         @RequestParam(value = "email", required = false, defaultValue = "") String email,
                         Model model) {
    if (amount == null) {
        amount = String.valueOf(0L); // Valoare implicită pentru amount dacă nu este furnizat
    }
    if (bookingId == null) {
        bookingId = ""; // Valoare implicită pentru bookingId dacă nu este furnizat
    }
    if (paymentId == null) {
        paymentId = ""; // Valoare implicită pentru paymentId dacă nu este furnizat
    }
    // Construiește obiectul Request utilizând valorile primite
    Request request = new Request();
    request.setPaymentId(paymentId);
    request.setBookingId(bookingId);
    Long parseAmount = Double.valueOf(amount).longValue();
    request.setAmount(parseAmount);
    request.setEmail(email);

    // Adaugă obiectul Request la model
    model.addAttribute("request", request);

    return Mono.just("index");
}


    @GetMapping("/error")
    public Mono<String> errorPage(Model model) {
        paymentService.fetchAndDisplayPayments();
        return Mono.just("error");
    }
    @GetMapping("/success")
    public Mono<String> successPage() {
        paymentService.fetchAndDisplayPayments();
        return Mono.just("success");
    }

    @PostMapping("/")
    public Mono<String> showCard(@ModelAttribute Request request,
                                 BindingResult bindingResult,
                                 Model model) {
        if (bindingResult.hasErrors()) {
            return Mono.just("index");
        }
        model.addAttribute("publicKey", publicKey);
        model.addAttribute("amount", request.getAmount());
        model.addAttribute("email", request.getEmail());
        model.addAttribute("bookingId", request.getBookingId());
        model.addAttribute("paymentId", request.getPaymentId());
        return Mono.just("checkout");
    }
}
