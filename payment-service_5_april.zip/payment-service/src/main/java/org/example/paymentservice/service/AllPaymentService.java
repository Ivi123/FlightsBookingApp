package org.example.paymentservice.service;

import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.model.PaymentIntentCollection;
import org.example.dto.PaymentRequest;
import org.example.paymentservice.model.Payment;
import org.example.paymentservice.producer.KafkaProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class AllPaymentService {
    private static final Logger log = LoggerFactory.getLogger(AllPaymentService.class);
    private final PaymentService paymentService;
    private final KafkaProducer kafkaProducer;

    public AllPaymentService(PaymentService paymentService, KafkaProducer kafkaProducer) {
        this.paymentService = paymentService;
        this.kafkaProducer = kafkaProducer;
    }


    public void fetchAndDisplayPayments() {

        // Configurare paginare pentru a obține toate plățile
        Map<String, Object> params = new HashMap<>();
        params.put("limit", 1); // Numărul maxim de plăți pe pagină

        try {
            // Interoghează plățile folosind API-ul Stripe
            PaymentIntentCollection payments = PaymentIntent.list(params);

            for (PaymentIntent intent : payments.getData()) {
                Map<String, String> metadata = intent.getMetadata();
                String bookingId = metadata.get("bookingId");
                String paymentId = metadata.get("paymentId");
                log.info("*** Status payment: {}", paymentId);
                log.info("*** for booking: {} ", bookingId);
                log.info("*** {}", intent.getStatus());
                //update status in bd
                if (!intent.getStatus().equalsIgnoreCase("succeeded")) {
                    paymentService.updatePaymentStatus(paymentId, "failed");
                } else {
                    paymentService.updatePaymentStatus(paymentId, "succeeded");
                }
                Payment p = paymentService.findById(paymentId);
                PaymentRequest paymentRequest = new PaymentRequest(
                        p.getId(),
                        p.getBookingId(),
                        p.getPrice(),
                        p.getCardNumber(),
                        p.getCardHolderName(),
                        p.getExpirationMonth(),
                        p.getExpirationYear(),
                        p.getCvv(),
                        p.getCurrency(),
                        p.getStatus()
                );
                kafkaProducer.sendMessage(bookingId, paymentRequest);
                break;
            }
        } catch (StripeException e) {
            e.printStackTrace();
        }
    }
}