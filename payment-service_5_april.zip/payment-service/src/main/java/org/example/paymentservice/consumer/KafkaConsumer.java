package org.example.paymentservice.consumer;


import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.example.dto.PaymentRequest;
import org.example.paymentservice.model.Payment;
import org.example.paymentservice.service.PaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;

@Service
public class KafkaConsumer {
    private final PaymentService paymentService;
    private static final Logger log = LoggerFactory.getLogger(KafkaConsumer.class);



    public KafkaConsumer(PaymentService paymentService) {
        this.paymentService = paymentService;

    }


    @KafkaListener(topics = "payment-request-topic", groupId = "payment-service")
    public void listen(ConsumerRecord<String, PaymentRequest> consumerRecord, Acknowledgment ak) {
        try {
            PaymentRequest paymentRequest = consumerRecord.value();
            // primire mesaj
            log.info(MessageFormat.format("Payment request received: value: {0} key: {1}", consumerRecord.value(), consumerRecord.key()));
            //salvare in bd
            Payment payment = new Payment(
                    paymentRequest.getId().toString(),
                    paymentRequest.getBookingId().toString(),
                    paymentRequest.getPrice(),
                    paymentRequest.getCardNumber().toString(),
                    paymentRequest.getCardHolderName().toString(),
                    paymentRequest.getExpirationMonth().toString(),
                    paymentRequest.getExpirationYear().toString(),
                    paymentRequest.getCvv(),
                    paymentRequest.getCurrency().toString(),
                    paymentRequest.getStatus().toString()

            );
            //verificare daca a mai fost procesat acest mesaj:
            Payment existingPayment = paymentService.findByCustomIdAndBookingId(payment.getId(),
                    payment.getBookingId());
            if (existingPayment != null) {
                log.error("Found a duplicate message id:{}", consumerRecord.key());
                return;
            }
            paymentService.savePayment(payment);
            log.info("Payment: {} saved in bd!", payment);


            // Afișarea link-ului către plata online
            log.info("Please make the payment here: ");

            String paymentLink = "http://localhost:8085/?" +
                    "paymentId=" + payment.getId() +
                    "&bookingId=" + payment.getBookingId() +
                    "&amount=" + payment.getPrice() +
                    "&email=" + payment.getCardHolderName();
                log.info(paymentLink);
            ak.acknowledge();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}