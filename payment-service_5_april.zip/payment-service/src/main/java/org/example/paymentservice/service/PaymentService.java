package org.example.paymentservice.service;

import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import org.example.paymentservice.model.Payment;
import org.example.paymentservice.model.Request;
import org.example.paymentservice.model.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.util.Map;

@Service
public class PaymentService {
    private final MongoTemplate mongoTemplate;
    private final static Logger log = LoggerFactory.getLogger(PaymentService.class);

    public PaymentService(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }


    public Mono<Response> processPaymentRequest(Request request) {
        try {
            PaymentIntentCreateParams params =
                    PaymentIntentCreateParams.builder()
                            .setAmount(request.getAmount() * 100L)
                            .putMetadata("bookingId", request.getBookingId())
                            .putMetadata("paymentId", request.getPaymentId())
                            .setCurrency("ron")
                            .setAutomaticPaymentMethods(
                                    PaymentIntentCreateParams.AutomaticPaymentMethods.builder()
                                            .setEnabled(true)
                                            .build()
                            )
                            .build();

            PaymentIntent intent = PaymentIntent.create(params);
            Map<String, String> metadata = intent.getMetadata();
            String bookingId = metadata.get("bookingId");
            String paymentId = metadata.get("paymentId");

            // Get the payment status
            String paymentStatus = intent.getStatus();
            Response response = new Response(intent.getId(), intent.getClientSecret());
            response.setBookingId(bookingId);
            response.setPaymentId(paymentId);
            response.setStatus(paymentStatus); // Set the payment status in the response
            log.info("Payment:" + paymentId + " for booking id: " + bookingId + "status: " + paymentStatus);
            return Mono.just(response);
        } catch (StripeException e) {
            e.printStackTrace();
            Response response = new Response("error", "");
            response.setBookingId(request.getBookingId());
            return Mono.just(response);
        }
    }


    public Payment findByCustomIdAndBookingId(String id, String bookingId) {
        // Folosim metoda findOne pentru a căuta în MongoDB după ID și bookingId
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(id).and("bookingId").is(bookingId));
        return mongoTemplate.findOne(query, Payment.class);
    }

    public Payment findById(String id) {
        return mongoTemplate.findById(id, Payment.class);
    }

    public void savePayment(Payment payment) {
        mongoTemplate.save(payment);
    }

    @Transactional
    public void updatePaymentStatus(String paymentId, String newStatus) {
        Payment payment = findById(paymentId);
        if (payment != null) {
            payment.setStatus(newStatus); // Actualizăm statusul plății
            mongoTemplate.save(payment); // Salvăm modificările în baza de date
        } else {
            throw new RuntimeException("Plata cu ID-ul " + paymentId + " nu a fost găsită.");
        }
    }


}
