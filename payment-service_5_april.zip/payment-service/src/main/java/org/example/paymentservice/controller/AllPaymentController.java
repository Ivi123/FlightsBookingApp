package org.example.paymentservice.controller;

import org.example.paymentservice.service.AllPaymentService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/payments")
public class AllPaymentController {

    private final AllPaymentService paymentService;

    public AllPaymentController(AllPaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @GetMapping("/fetchAndDisplay")
    public String fetchAndDisplayPayments() {
        paymentService.fetchAndDisplayPayments();
        return "Plățile au fost interogate și afișate cu succes!";
    }
}
