package org.example.paymentservice.controller;


import org.example.paymentservice.model.Request;
import org.example.paymentservice.model.Response;
import org.example.paymentservice.service.PaymentService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;


@RestController
public class PaymentIntentController {

    private final PaymentService paymentService;


    public PaymentIntentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/create-payment-intent")
    public Mono<Response> createPaymentIntent(@RequestBody Request request) {
        return paymentService.processPaymentRequest(request);
    }
}
